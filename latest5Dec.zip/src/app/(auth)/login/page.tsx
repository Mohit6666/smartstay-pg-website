// "use client";

// import { Input } from "@/components/ui/input";
// import { Label } from "@/components/ui/label";
// import { Button } from "@/components/ui/button";

// export default function LoginPage() {
//   return (
//     <div className="w-full">
//       <div className="">
//         <h2 className="text-xl font-semibold text-neutral-900">Sign In to MB Academy</h2>
//         <p className="mt-2 text-sm text-neutral-500">Access your courses, community and events.</p>
//       </div>

//       {/* Form */}
//       <div className="mt-10 space-y-4">
//         <div className="space-y-2">
//           <Label className="text-[#0F1828]">Email Address</Label>
//           <Input placeholder="Enter your email" />
//         </div>

//         <div className="space-y-2">
//           <Label className="text-[#0F1828]">Password</Label>
//           <Input type="password" placeholder="Enter your password" />
//           <p className="cursor-pointer text-right text-xs text-neutral-500 hover:underline">Forgot Password?</p>
//         </div>

//         <Button className="w-full">Sign In</Button>

//         <p className="text-center text-sm text-neutral-600">or</p>

//         <div className="space-y-3">
//           <Button variant="outline" className="w-full">
//             Continue with Google
//           </Button>
//           <Button variant="outline" className="w-full">
//             Continue with Apple
//           </Button>
//         </div>

//         <p className="text-center text-sm">
//           Don’t have an account?{" "}
//           <span className="cursor-pointer font-semibold text-black hover:underline">Create Account</span>
//         </p>
//       </div>
//     </div>
//   );
// }
"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { Eye, EyeOff } from "lucide-react";

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="w-full">
      {/* Title */}
      <h2 className="text-2xl font-bold text-[#0F1828]">Sign In to MB Academy</h2>
      <p className="mt-2 text-sm text-neutral-600">Access your courses, community and events.</p>

      {/* Form */}
      <div className="mt-10 space-y-5">
        {/* Email */}
        <div className="space-y-2">
          <Label className="text-sm text-[#0F1828]">Email Address</Label>
          <Input
            placeholder="Enter your email"
            className="h-11 border-neutral-300 text-[#0F1828] placeholder-neutral-400 focus-visible:ring-[#0F1828]"
          />
        </div>

        {/* Password */}
        <div className="space-y-2">
          <Label className="text-sm text-[#0F1828]">Password</Label>

          <div className="relative">
            <Input
              type={showPassword ? "text" : "password"}
              placeholder="Enter your password"
              className="h-11 border-neutral-300 pr-10 text-[#0F1828] placeholder-neutral-400 focus-visible:ring-[#0F1828]"
            />

            {/* Eye Icon Button */}
            <button
              type="button"
              className="absolute inset-y-0 right-3 flex items-center text-neutral-500 hover:text-[#0F1828]"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>

          <Link href="/forgot-password" className="block text-right text-xs text-[#0F1828] hover:underline">
            Forgot Password?
          </Link>
        </div>

        {/* Sign In Button */}
        <Button className="h-11 w-full bg-[#0F1828] text-white hover:bg-[#0F1828]/90">Sign In</Button>

        {/* OR Divider */}
        <div className="text-center text-sm text-neutral-500">or</div>

        {/* Social Buttons */}
        <div className="space-y-3">
          <Button variant="outline" className="h-11 w-full border-neutral-300 text-[#0F1828]">
            Continue with Google
          </Button>
          <Button variant="outline" className="h-11 w-full border-neutral-300 text-[#0F1828]">
            Continue with Apple
          </Button>
        </div>

        {/* Signup Link */}
        <p className="text-center text-sm text-neutral-600">
          Don’t have an account?
          <Link href="/register" className="ml-1 font-semibold text-[#0F1828] hover:underline">
            Create Account
          </Link>
        </p>
      </div>
    </div>
  );
}
