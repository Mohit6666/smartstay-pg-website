"use client";

import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function WelcomePage() {
  return (
    <div className="space-y-6">
      <h2 className="text-center text-2xl font-bold">
        <span className="font-medium text-[#0F1828]"> Welcome to</span>{" "}
        <span className="size-lvh font-bold text-[#0F1828]">MB Academy</span>
      </h2>

      <div className="space-y-3">
        <Link href="/login">
          <Button className="w-full bg-[#15243B] hover:bg-[#0F1828]/90">Sign In</Button>
        </Link>

        <Link href="/register">
          <Button className="mt-5 w-full bg-[#15243B] hover:bg-[#0F1828]/90">Create Account</Button>
        </Link>
      </div>

      <div className="relative my-4 text-center text-sm text-neutral-500">
        <span className="relative z-10 bg-white px-2">or continue with</span>
        <div className="absolute inset-0 border-t border-neutral-200"></div>
      </div>

      <div className="space-y-3">
        <Button variant="outline" className="w-full">
          Continue with Google
        </Button>
        <Button variant="outline" className="w-full">
          Continue with Apple
        </Button>
      </div>

      <div className="space-x-3 pt-2 text-center text-xs text-neutral-500">
        <span>Privacy Policy</span> <span>Terms of Service</span>
      </div>
    </div>
  );
}
// export default function WelcomePage() {
//   return <div className="text-center text-xl font-semibold">Welcome Screen Working 🚀</div>;
// }
