import Image from "next/image";
import "../globals.css";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col bg-[#F8F7F2] p-10 lg:grid lg:grid-cols-2">
      {/* LEFT IMAGE VIEW - Centered + Proper Crop */}
      <div className="relative hidden items-center justify-center lg:flex">
        <div className="relative ml-40 h-full w-full overflow-hidden rounded-3xl">
          <Image src="/auth-bg.png" alt="Auth background" fill priority className="object-contain object-fill" />
        </div>
      </div>

      {/* RIGHT CARD VIEW - Bigger & Center */}
      <div className="flex w-full items-center justify-center rounded-3xl bg-white shadow-2xl lg:p-12">
        <div className="w-[80%]">{children}</div>
      </div>
    </div>
  );
}
